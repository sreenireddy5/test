package com.ilearn.repository;

import com.ilearn.model.Course;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

/**
 *
 * @author Sreeni Reddy
 */
public class CourseRepositoryTest {
    
    CourseRepository repository = new CourseRepository();
    @Test
    public void testFindAll() {
        assertEquals(3, repository.findAll().size());
    }
    @Test
    public void testFindById() {
        Course course = repository.findById("C04");
        assertEquals("angular", course.getName());
    }
    @Test
    public void testFindByIdNotFound() {
        assertEquals(null, repository.findById("C05"));
    }
}
