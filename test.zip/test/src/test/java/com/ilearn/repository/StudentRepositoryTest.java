package com.ilearn.repository;

import com.ilearn.model.Student;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

/**
 *
 * @author Sreeni Reddy
 */
public class StudentRepositoryTest {
    
    StudentRepository repository = new StudentRepository();
    @Test
    public void testFindAll() {
        assertEquals(3, repository.findAll().size());
    }
    @Test
    public void testFindById() {
        Student student = repository.findById(1);
        assertEquals("Sreeni", student.getName());
    }
    @Test
    public void testFindByIdNotFound() {
        assertEquals(null, repository.findById(5));
    }
}
