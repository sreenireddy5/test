package com.ilearn;

import com.ilearn.model.Course;
import com.ilearn.model.Student;
import java.util.Collection;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class TestApplicationIntegrationTests {

    @Autowired
    private TestRestTemplate restTemplate;
    
    @Test
    public void getStudent() {
        ResponseEntity<Student> responseEntity =
            getRestTemplate().getForEntity("/students/1", Student.class);
        Student student = responseEntity.getBody();
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("Sreeni", student.getName());
    }
    
    @Test
    public void getStudents() {
        ResponseEntity<Collection> responseEntity =
            getRestTemplate().getForEntity("/students", Collection.class);
        Collection collection = responseEntity.getBody();
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(3, collection.size());
    }
    
    @Test
    public void getCourses() {
        ResponseEntity<Collection> responseEntity =
            getRestTemplate().getForEntity("/courses", Collection.class);
        Collection collection = responseEntity.getBody();
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(3, collection.size());
    }
    
    @Test
    public void getCourse() {
        ResponseEntity<Course> responseEntity =
            getRestTemplate().getForEntity("/courses/C01", Course.class);
        Course course = responseEntity.getBody();
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("java", course.getName());
    }
    
    private TestRestTemplate getRestTemplate() {
        return restTemplate.withBasicAuth("admin", "password");
    }

}
