package com.ilearn.model;

/**
 *
 * @author Sreeni Reddy
 */
public abstract class Model<V> {
    private V id;
    
    public Model() {
        
    }
    
    public Model(V id) {
        this.id = id;
    }
    
    public V getId() {
        return id;
    }

    public void setId(V id) {
        this.id = id;
    }

}
