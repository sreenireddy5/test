package com.ilearn.repository;

import com.ilearn.model.Model;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 *
 * @author Sreeni Reddy
 */
public abstract class Repository<T extends Model<? extends Object>> {
    
    List<T> collection = new ArrayList<>();
    
    public Collection<T> findAll() {
        return collection;
    }
    
    public T findById(Object id) {
        return collection.stream().filter(x -> x.getId().equals(id)).findFirst().orElse(null);
    } 
    
}
