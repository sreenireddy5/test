package com.ilearn.repository;

import com.ilearn.model.Student;
import java.time.LocalDate;
import java.time.Month;
import org.springframework.stereotype.Component;

/**
 *
 * @author Sreeni Reddy
 */
@Component
public class StudentRepository extends Repository<Student> {
    
    public StudentRepository() {
        collection.add(new Student(1,"Sreeni", LocalDate.of(1980, Month.MARCH, 1)));
        collection.add(new Student(2,"John", LocalDate.of(1983, Month.OCTOBER, 16)));
        collection.add(new Student(3,"Adam", LocalDate.of(1986, Month.APRIL, 10)));
    }
    
}
