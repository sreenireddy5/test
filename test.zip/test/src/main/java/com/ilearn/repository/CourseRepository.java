package com.ilearn.repository;

import com.ilearn.model.Course;
import java.time.LocalDate;
import java.time.Month;
import org.springframework.stereotype.Component;

/**
 *
 * @author Sreeni Reddy
 */
@Component
public class CourseRepository extends Repository<Course> {
    
    public CourseRepository() {
        collection.add(new Course("C01","java", LocalDate.of(1980, Month.MARCH, 1), LocalDate.of(1980, Month.MARCH, 10)));
        collection.add(new Course("C02","nodejs", LocalDate.of(1983, Month.OCTOBER, 16), LocalDate.of(1983, Month.OCTOBER, 26)));
        collection.add(new Course("C04","angular", LocalDate.of(1982, Month.MARCH, 14), LocalDate.of(1982, Month.MARCH, 19)));
        
    }
    
}
