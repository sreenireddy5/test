package com.ilearn.controller;

import com.ilearn.repository.StudentRepository;
import com.ilearn.model.Student;
import java.util.Collection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Sreeni Reddy
 */
@RestController
@RequestMapping("/students")
public class StudentsController {
    @Autowired
    private StudentRepository studentRepository;
    
    @RequestMapping(method = RequestMethod.GET)
    Collection<Student> getStudents() {
            return this.studentRepository.findAll();
    }
    
    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    Student getStudent(@PathVariable Integer id) {
            return this.studentRepository.findById(id);
    }
}
