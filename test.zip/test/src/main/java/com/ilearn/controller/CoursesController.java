package com.ilearn.controller;

import com.ilearn.model.Course;
import com.ilearn.repository.CourseRepository;
import java.util.Collection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Sreeni Reddy
 */
@RestController
@RequestMapping("/courses")
public class CoursesController {
    @Autowired
    private CourseRepository courseRepository;
    
    @RequestMapping(method = RequestMethod.GET)
    Collection<Course> getCourses() {
            return this.courseRepository.findAll();
    }
    
    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    Course getCourse(@PathVariable String id) {
            return this.courseRepository.findById(id);
    }
}
